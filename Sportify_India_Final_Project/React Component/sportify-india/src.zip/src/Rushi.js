
export default function Rushi(){
    return(<div>Hello </div>)
}